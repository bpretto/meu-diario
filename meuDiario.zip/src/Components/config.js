// sua configuração do Firebase
const FirebaseKey = {
  apiKey: "AIzaSyDx8bQHNjmAau-Zb9T0Yxhxtjf3fSINkKo",
  authDomain: "meu-diario-67507.firebaseapp.com",
  databaseURL: "https://meu-diario-67507-default-rtdb.firebaseio.com",
  projectId: "meu-diario-67507",
  storageBucket: "meu-diario-67507.appspot.com",
  messagingSenderId: "1054934621271",
  appId: "1:1054934621271:web:d1cff6bd4b473d82bb5712"
};

export default FirebaseKey;
