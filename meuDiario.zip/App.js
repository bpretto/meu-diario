import React from 'react';
import Routes from './src/Routes/routes';

export default function App() {
  return (
    <Routes/>
  );
}
